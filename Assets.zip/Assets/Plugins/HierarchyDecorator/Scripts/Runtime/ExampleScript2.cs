﻿using UnityEngine;

namespace HierarchyDecorator
{
    public class ExampleScript2 : MonoBehaviour
    {

    }
}