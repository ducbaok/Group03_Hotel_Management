using UnityEngine;
using UnityEngine.UIElements;

namespace YNL.Checkotel
{
    public partial class InformationViewFacilitiesPageUI : ViewPageUI
    {
        protected override void Collect()
        {
        }

        protected override void Initialize()
        {
        }
    }
}