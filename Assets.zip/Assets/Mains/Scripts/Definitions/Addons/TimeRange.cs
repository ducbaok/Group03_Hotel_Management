namespace YNL.Checkotel
{
    [System.Serializable]
    public struct TimeRange
    {
        public byte TimeIn;
        public byte TimeOut;
    }
}