﻿namespace YNL.Checkotel
{
    public enum HotelFilteringType
    {

    }

    public enum HotelSearchingType
    {

    }

    public enum HotelVerificationType
    {

    }
}
